function main() {
  // Distances in miles
  const restaurantDistances = [2.2, 6.2, 7, 5.1];

  const distancesInKm: number[] = [];
  for (const miles of restaurantDistances) {
    distancesInKm.push(miles * 1.6);
  }
  console.log(distancesInKm);

  const walkingTimes: number[] = [];
  for (const miles of restaurantDistances) {
    // for simplicity assume walking speed of 3MPH
    walkingTimes.push(miles / 3);
  }
  console.log(walkingTimes);

  // Step 1: Let's print one of these arrays, one item per line,
  // formatted to 2 decimal places.

  // Step 2: What duplicated structure do we see in the code?

  // Step 3: Let's write a function that abstracts that structure

  // Step 4: Refactor the walkingTimes and distancesInKm computations.

  // Question: Why is this possible?

  // Step 5: Let's print our walking times one per line, 2 decimal places

  // Step 6: Can we get rid of those one-off functions?

  // Aside (if time): Multi-statement arrow functions

  // (If time): Let's try using the built-in Array.map instead
}

function distanceInKm(distance: number) {
  return distance * 1.6;
}

function walkingTime(miles: number): number {
  return miles / 3;
}

function two_decimal_places(num: number): string {
  return num.toFixed(2);
}

main();

export {};
