function main() {
  // What duplicated structure do we see in the two functions below?
  // Let's write a higher-order function that lets us abstract it away.

  console.log(filterNonEmpty(["waa", "luigi", "", "time", ""]));
  console.log(filterEven([1, 2, 3, 4, 5]));
}

function filterNonEmpty(strs: string[]): string[] {
  const result: string[] = [];
  for (const item of strs) {
    if (item.length !== 0) {
      result.push(item);
    }
  }
  return result;
}

function filterEven(nums: number[]): number[] {
  const result: number[] = [];
  for (const item of nums) {
    if (item % 2 === 0) {
      result.push(item);
    }
  }
  return result;
}

main();

export {};
