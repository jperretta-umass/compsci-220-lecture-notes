// // Implement the function eltDiffs below.
// // Your solution may not use loops, listToArray, or arrayToList

// import { List } from "./include/lists.js";

// // Given a list, returns a new list that contains the differences
// // between each contiguous pair of elements in the list.
// // For example, (42 43 40 45) would result in (1 -3 5)
// function eltDiffs(list: List<number>): List<number> {
//   // BEGIN SOLUTION
//   // Tail recursive solution, uses helper function below
//   // END SOLUTION

//   // BEGIN SOLUTION
//   // Solution using reduce
//   let prev: number | null = null;
//   // END SOLUTION
// }

// // BEGIN SOLUTION
// function eltDiffsTail(list: List<number>, prev: number | null, result: List<number>): List<number> {
//   // if ()
// }
// // END SOLUTION
