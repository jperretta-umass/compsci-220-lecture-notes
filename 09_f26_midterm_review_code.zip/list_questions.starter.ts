// Implement the function eltDiffs below.
// Your solution may not use loops, listToArray, or arrayToList

import { empty, List, node, reverseList } from "./include/lists.js";

// Given a list, returns a new list that contains the differences
// between each contiguous pair of elements in the list.
// For example, (42 43 40 45) would result in (1 -3 5)
function eltDiffs(list: List<number>): List<number> {

}
