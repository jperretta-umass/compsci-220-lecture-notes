// Implement the function eltDiffs below.
// Your solution may not use loops, listToArray, or arrayToList

import { empty, List, node, reverseList } from "./include/lists.js";

// Given a list, returns a new list that contains the differences
// between each contiguous pair of elements in the list.
// For example, (42 43 40 45) would result in (1 -3 5)
function eltDiffs(list: List<number>): List<number> {
  // BEGIN SOLUTION
  // Tail recursive solution, uses helper function below
  if (list.isEmpty()) {
    return list;
  }
  return reverseList(eltDiffsTail(list.tail(), list.head(), empty()));
  // END SOLUTION

  // BEGIN SOLUTION
  // Solution using reduce
  // if (list.isEmpty()) {
  //   return list;
  // }
  // let prev: number = list.head();
  // return reverseList(list.tail().reduce((so_far, elt) => {
  //   let diff = elt - prev;
  //   prev = elt;
  //   return node(diff, so_far);
  // }, empty()));
  // END SOLUTION
}

// BEGIN SOLUTION
function eltDiffsTail(list: List<number>, prev: number, result: List<number>): List<number> {
  if (list.isEmpty()) {
    return result;
  }
  return eltDiffsTail(list.tail(), list.head(), node(list.head() - prev, result));
}
// END SOLUTION
