// The full code for these examples can be found in the lecture notes.

// 1. Examine the Swallow and Duck classes below.
// 2. Add an abstract base class Bird. Refactor Swallow and Duck.
// 3. Update Swallow so that its speed is reduced based on how many
//    coconuts it's carrying.
// 4. Consider how we would update our hierarchy if we wanted to
//    add an Airplane class.
// 5. Examine the Movement class further below in this file.
//    Refactor the Bird hierarchy to use composition ("has-a")
//    for its movement functionality.
// 6. Write an interface "Movable" with getLocation, setDestination, and move.

class Swallow {
  constructor(
    private speed: number,
    private location: number,
  ) {}

  talk() {
    console.log("Tweet");
  }

  getSpeed() {
    return this.speed;
  }

  getLocation() {
    return this.location;
  }

  setDestination(location: number) {
    // Move one time unit towards the given location. Omitted for brevity.
  }
}

class Duck {
  constructor(
    private speed: number,
    private location: number,
  ) {}

  talk() {
    console.log("Quack");
  }

  getSpeed() {
    return this.speed;
  }

  getLocation() {
    return this.location;
  }

  setDestination(location: number) {
    // Move one time unit towards the given location. Omitted for brevity.
  }
}

// ----------------------------------------------------------------------

class Movement {
  private destination: number;
  // We can set a default speed of zero
  private speed: number = 0;

  constructor(private location: number) {
    // Set the initial destination to the current location
    this.destination = location;
  }

  getSpeed() {
    return this.speed;
  }

  setSpeed(speed: number) {
    this.speed = speed;
  }

  getLocation() {
    return this.location;
  }

  setDestination(destination: number) {
    this.destination = destination;
  }

  move() {
    // Move towards destination. Omitted for brevity.
  }
}

// --------------------------------------------------------------

// We need a "Movable" interface to declare the type of this array.
// const movableObjects = [new Duck(...), new Swallow(...), new PassengerJet(...), ...];
