// The full code for these examples can be found in the lecture notes.

class Parrot {
  constructor(public age: number) {}
}

const parrots = [new Parrot(42), new Parrot(43)];

// range-based for-loop
for (const parrot of parrots) {
  parrot.age += 1;
}
console.log(parrots);

// Array.forEach
parrots.forEach((parrot) => {
  parrot.age += 1;
});
console.log(parrots);
