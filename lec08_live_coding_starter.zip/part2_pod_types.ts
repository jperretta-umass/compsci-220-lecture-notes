// The full code for these examples can be found in the lecture notes.

class Reservation {
  readonly id: string;
  name: string;
  partySize: number;

  constructor(id: string, name: string, partySize: number) {
    this.id = id;
    this.name = name;
    this.partySize = partySize;
  }
}

// Modify this class to use the constructor parameter list shorthand
// for declaring and initializing member variables.
