// The full code for these examples can be found in the lecture notes.

// 1. Use a POD class to return the new location and distance moved
// 2. Use a tuple & destructuring
// 3. Use an object literal & destructuring

function moveTowards(start: number, destination: number, speed: number) {
  const distanceToDestination = destination - start;
  if (distanceToDestination < speed) {
    // UPDATE ME to return destination and distanceToDestination
  }
  // UPDATE ME to return start + speed and speed
}

// Uncomment after updating the above return statements.
//
// const result1 = moveTowards(1, 5, 3);
// console.log(
//   `Moved ${result1.distanceMoved} units to location ${result1.newLocation}`,
// );
// const result2 = moveTowards(3, 5, 3);
// console.log(
//   `Moved ${result2.distanceMoved} units to location ${result2.newLocation}`,
// );
