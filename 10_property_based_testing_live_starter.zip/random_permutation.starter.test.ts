import { random_permutation, shuffle } from "./random_permutation";

// Note: We could also randomly generate our inputs
const input = ["w", "a", "l", "u", "i", "g"];
test('How do I test this?', () => {
  expect(
    random_permutation(input)
  ).toEqual([ "g", "w", "a", "l", "u", "i"]);
});

// What are the *properties* of a random permutation that we can check?

