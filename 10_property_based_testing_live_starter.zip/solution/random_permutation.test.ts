import { random_permutation, shuffle } from "./random_permutation";

// Note: We could also randomly generate our inputs
const input = ["w", "a", "l", "u", "i", "g"];
// SKELETON test('How do I test this?', () => {
// BEGIN SOLUTION
test.skip("How do I test this?", () => {
  // END SOLUTION
  expect(
    random_permutation(input)
  ).toEqual([ "g", "w", "a", "l", "u", "i"]);
});

// What are the *properties* of a random permutation that we can check?

// BEGIN SOLUTION
const num_trials = 10;

for (let i = 0; i < num_trials; ++i) {
  describe(`Random permutation tests: Trial ${i} `, () => {
    const actual = random_permutation(input);
    test('Permutation length', () => {
      // BEGIN SOLUTION
      expect(actual.length).toBe(input.length);
      // END SOLUTION
    });

    // Is this property correct in all cases?
    // BEGIN SOLUTION
    // Extra practice: How would you need to update this for
    // the array ["w", "a", "l", "u", "i", "g", "i"]?
    // END SOLUTION
    test("All elements seen once", () => {
      // BEGIN SOLUTION
      const seen = new Set<string>();
      for (const c of actual) {
        expect(seen.has(c)).toBe(false);
        seen.add(c);
      }
      // END SOLUTION
    });
  });
}
// END SOLUTION
