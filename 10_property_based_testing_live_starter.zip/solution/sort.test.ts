import { random_choice, random_int } from "./random_permutation";

class Apple {
  constructor(public readonly variety: string, public readonly weight: number) {}
}
const varieties = ["crab", "pippin", "golden russet", "macoun", "honeycrisp"];

// Returns an array of num_apples randomly created Apples.
// Varieties are chosen from the "varieties" array, and
// weights are between 1 and 10 ounces, inclusive.
function make_apples(num_apples: number) {
  // BEGIN SOLUTION
  // Create an array of size num_apples, then use map
  // to create a new array of the same size but with random
  // apples in it.
  // If that seems wasteful, it is. If it seems less expressive than
  // a Python list comprehension, I agree :)
  return Array(num_apples).fill("").map( // why javascript, why (all of the ways of doing this elicit the same response)
    (_) => new Apple(random_choice(varieties), random_int(1, 10)),
  );
  // END SOLUTION
}

function test_in_place_sort(
  input_generator: (n: number) => Apple[],
  sort_func: (array: Apple[]) => void,
) {
  const num_trials = 10;
  for (let i = 0; i < num_trials; ++i) {
    describe(`Test in-place Sort: Trial ${i}`, () => {
      const input = input_generator(3);//random_int(0, 100));
      const result = [...input];
      sort_func(result);

      // What properties should we check to see if the result is sorted?
      // BEGIN SOLUTION
      test('Same length', () => {
        expect(input.length).toEqual(result.length);
      });

      test('Non-decreasing order', () => {
        if (result.length === 0) {
          return;
        }
        let prev = result[0];
        for (const elt of result.slice(1)) {
          expect(elt.weight).toBeGreaterThanOrEqual(prev.weight);
        }
      });

      test('Original data present', () => {
        const expected_counts = get_counts(input, (a) => `${a.variety}, ${a.weight}oz`);
        const actual_counts = get_counts(result, (a) => `${a.variety}, ${a.weight}oz`);
        expect(actual_counts).toEqual(expected_counts);
      });
      // END SOLUTION
    });
  }
}

// In Python, we could use a Counter object, but alas, we'll
// have to write something good enough ourselves
function get_counts<T>(items: T[], key_func: (item: T) => string) {
  const counts = new Map<string, number>();
  for (const item of items) {
    const key = key_func(item);
    // Next line is roughly equivalent to:
    //   "0 if counts.get(key) is undefined, else counts.get(key)"
    // Map.get() returns undefined if the key is not in the map.
    const cur_count = counts.get(key) ?? 0;
    counts.set(key, cur_count + 1);
  }

  // Array.from(counts) gives us an array of [string, number] tuples
  return Array.from(counts).sort(
    (a, b) => a[0].localeCompare(b[0])
  );
}

// Implement the function test_in_place_sort.
// It takes in an input generator function, a sorting function,
// and a comparator to pass to the sorting function.
test_in_place_sort(make_apples, (array: Apple[]) => array.sort((a, b) => a.weight - b.weight));
