export function random_permutation<T>(array: T[]) {
  // This implementation is inneficient O(n^2)
  const used_indices = new Set<number>();
  const result = [];
  while (used_indices.size < array.length) {
    const index = random_int(0, array.length - 1);
    if (used_indices.has(index)) {
      continue;
    }

    result.push(array[index]);
    used_indices.add(index);
  }
  return result;
}

// O(n) shuffle algorithm
// This can be done in place, but this implementation
// makes a copy.
export function shuffle<T>(array: ReadonlyArray<T>) {
  const result = Array.from(array);
  let to_swap = result.length - 1;
  while (to_swap >= 1) {
    const swap_with = random_int(0, to_swap);
    // SKELETON swap(result[to_swap], result[swap_with]);
    // BEGIN SOLUTION
    const temp = result[to_swap];
    result[to_swap] = result[swap_with];
    result[swap_with] = temp;
    to_swap -= 1;
    // END SOLUTION
  }
  return result;
}

// SKELETON // Does this work?
// SKELETON function swap<T>(a: T, b: T) {
// SKELETON   const temp = a;
// SKELETON   a = b;
// SKELETON   b = temp;
// SKELETON }

// Return a random integer in the range [min, max] (inclusive).
export function random_int(min: number, max: number) {
  return Math.floor(Math.random() * (max + 1) + min);
}

export function random_choice<T>(array: T[]) {
  const index = random_int(0, array.length - 1);
  console.log(index, array.length);
  return array[index];
}
