import { number_to_ordinal } from "./number_to_ordinal.js";

test('1, 2, 3', () => {
  expect(number_to_ordinal(1)).toEqual("1st");
  expect(number_to_ordinal(2)).toEqual("2nd");
  expect(number_to_ordinal(3)).toEqual("3rd");
});

test('Ends in 1, 2, 3', () => {
  expect(number_to_ordinal(21)).toEqual("21st");
  expect(number_to_ordinal(22)).toEqual("22nd");
  expect(number_to_ordinal(23)).toEqual("23rd");
});

test("11, 12, 13", () => {
  expect(number_to_ordinal(11)).toEqual("11th");
  expect(number_to_ordinal(12)).toEqual("12th");
  expect(number_to_ordinal(13)).toEqual("13th");
});

test("Ends in 11, 12, 13", () => {
  expect(number_to_ordinal(111)).toEqual("111th");
  expect(number_to_ordinal(112)).toEqual("112th");
  expect(number_to_ordinal(113)).toEqual("113th");
});

test('Everything else gets th - boundary cases', () => {
  expect(number_to_ordinal(20)).toEqual("20th");
  expect(number_to_ordinal(24)).toEqual("24th");
  expect(number_to_ordinal(30)).toEqual("30th");
});

test('Everything else gets th - general cases', () => {
  expect(number_to_ordinal(35)).toEqual("35th");
});
