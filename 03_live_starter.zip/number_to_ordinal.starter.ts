// Benefits of code coverage
// - Points us toward untested code

// Limitations of code coverage (examples)
// - Missing "expect"s
// - 11/12/13 branch
// - Is Implementation B correct?

// Returns the ordinal representation of the given integer.
export function number_to_ordinal(num: number) {
  // IMPLEMENTATION A
  const as_str = num.toString();

  if (as_str.endsWith("11") || as_str.endsWith("12") || as_str.endsWith("13")) {
    return as_str + "th";
  }

  if (as_str.endsWith("1")) {
    return as_str + "st";
  }

  if (as_str.endsWith("2")) {
    return as_str + "nd";
  }

  if (as_str.endsWith("3")) {
    return as_str + "rd";
  }

  return as_str + "th";

  // IMPLEMENTATION B
  // if (num % 100 === 11 || num % 100 === 12 || num % 100 === 13) {
  //   return `${num}th`;
  // }

  // if (num % 10 === 1) {
  //   return `${num}st`;
  // }
  // if (num % 10 === 2) {
  //   return `${num}nd`;
  // }
  // if (num % 10 === 3) {
  //   return `${num}rd`;
  // }

  // return `${num}th`;
}
