// How should we approach writing tests for map and filter?

describe('map tests', () => {
    test.skip('', () => {
      throw new Error("TODO");
    });
});

describe('filter tests', () => {
  test.skip('', () => {
    throw new Error("TODO");
  });
});
