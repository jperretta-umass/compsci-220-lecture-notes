// Part 1: Implement a function `min_element` that could be used to refactor the code below.
// Decide how you want it to behave when passed an empty array.

const numbers = [
  6, 3, 8, 2, 9, 7, 2
];
let min = numbers[0];
for (const num of numbers) {
  if (num < min) {
    min = num;
  }
}
console.log(min);

const dates = [
  "2026-02-20", "2026-02-23", "2026-02-21"
];
let earliest = dates[0];
for (const date of dates) {
  if (date.localeCompare(earliest) < 0) {
    earliest = date;
  }
}
console.log(earliest);

// BEGIN SOLUTION
function min_element<T>(array: T[], lessThan: (a: T, b: T) => boolean) {
  let min = array[0];
  for (const item of array) {
    if (lessThan(item, min)) {
      min = item;
    }
  }
  return min;
}

function exercise0p1solution() {
  const numbers = [6, 3, 8, 2, 9, 7, 2];
  console.log(min_element(numbers, (a, b) => a < b));

  const dates = ["2026-02-20", "2026-02-23", "2026-02-21"];
  console.log(min_element(dates, (a, b) => a.localeCompare(b) < 0));
}
exercise0p1solution();
// END SOLUTION

// Part 2: Implement the function earliest_submissions below.
// Your solution may not use loops or reduce, but you can
// use other array methods and min_element.

// Returns an array containing the earliest submission from each user.
// The form submissions are not sorted.
// If a user has no submissions, the returned array should contain undefined.
function earliest_submissions(users: string[], submissions: Submission[]) {
  // BEGIN SOLUTION
  return users.map((user) => {
    const for_user = submissions.filter(
      (submission) => submission.user === user,
    );
    if (for_user.length === 0) {
      return undefined;
    }
    return min_element(
      for_user,
      (a, b) => a.timestamp.localeCompare(b.timestamp) < 0,
    );
  });
  // END SOLUTION
}

class Submission {
  constructor(public readonly user: string, public readonly timestamp: string) {}
}
const submissions = [
  new Submission("WALUIGI", "2026-02-24"), new Submission("WALUIGI", "2026-02-21"),
  new Submission("sanic", "2026-01-31"), new Submission("sanic", "2026-02-20"),
];
const earliest_subs = earliest_submissions(
  ["sanic", "knuckles", "WALUIGI"], submissions);
console.log(earliest_subs);
// '2026-01-31' for sanic, undefined for knuckles, '2026-02-21' for WALUIGI
