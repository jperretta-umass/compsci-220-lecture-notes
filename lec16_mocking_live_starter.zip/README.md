# Instructions

Install dependencies:
```
npm ci
```

Compile the code:
```
npm run build
```

Run the top-level game:
```
node out/main.js
```

Run the tests:
```
npm test
```

To run a specific test file by itself, say, `game2.test.ts` (we'll create extra files during class):
```
npm test -- game2.test.ts
```
