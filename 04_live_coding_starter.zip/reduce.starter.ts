// Below are two functions, sum and flatten.
// Write a higher-order function that abstracts the
// structure of these functions.
// 1. What are the structural similarities?
// 2. What do the input parameters, local variables, and return values
//    between the two functions have in common? I.e., what generic
//    type variables do we need?
// 3. What kind of function should our higher-order function
//    take in as an input parameter?
// 4. Update the calls to flatten and sum in main to use the new
//    function.
// 5. Is that code better?

function main() {
  console.log(flatten([["egg"], ["bacon", "spam"]]));
  console.log(sum([42, 43, 44]));
}

function sum(values: number[]): number {
  let result = 0;
  for (const val of values) {
    result += val;
  }
  return result;
}

function flatten<T>(arrays: T[][]): T[] {
  let result: T[] = [];
  for (const array of arrays) {
    result = result.concat(array);
  }
  return result;
}

main();

export {};
