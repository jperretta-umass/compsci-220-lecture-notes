npm run build && node out/$(python3 -c "print('$1'.replace('.ts', '.js'))")
