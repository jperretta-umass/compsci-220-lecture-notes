// Declaring this inside a namespace lets us avoid name conflicts
// with typescript's built-in Iterator and IteratorResult types.
// You do not need to use namespaces in your assignment code.
namespace cs220 {
  interface Iterator<ValueType> {
    next(): IteratorResult<ValueType>;
  }

  interface IteratorResult<ValueType> {
    done: boolean;
    value?: ValueType;
  }

  class ArrayIterator<ValueType> implements Iterator<ValueType> {
    private index = 0;

    constructor(private array: ValueType[]) {}

    // 1. Implement the next() method to return the current element
    // and advance the iterator
    next(): IteratorResult<ValueType> {
      throw new Error("Not implemented");
    }
  }

  const items = ["spam", "egg", "sausage", "spam"];

  const iterator = new ArrayIterator(items);
  let current_result = iterator.next();
  while (!current_result.done) {
    console.log(current_result.value);
    current_result = iterator.next();
  }

  // 2. Update the DemoArray class below so that we can
  // request an iterator from it. It should work with a range-based
  // for loop after adding that.

  // class DemoArray<ItemType> implements Iterable<ItemType> {
  //   private _data: ItemType[];

  //   constructor(data: ItemType[]) {
  //     this._data = data;
  //   }
  // }

  // for (const item of new DemoArray(["waa", "luigi", "time"])) {
  //   console.log(item);
  // }
}
