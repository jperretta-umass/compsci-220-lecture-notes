type Pair<T, U> = readonly [T, U];

// 1. Update the zip function so that it returns an iterator (you'll need to
// define a custom iterator class and use it in the implementation)
export function zip<T, U>(array1: T[], array2: U[]): Pair<T, U>[] {
  const result: Pair<T, U>[] = [];
  for (let i = 0; i < array1.length && i < array2.length; i += 1) {
    result.push([array1[i], array2[i]]);
  }
  return result;
}

console.log(zip([1, 2, 3], [4, 5, 6]));
console.log(zip([1, 2, 3], [4, 5]));

// 2. Update the zip function/zip iterator so that it works with a range-based for-loop

// 3. What if we want to update the zip function so that it works on other containers besides just arrays?
// With our current tools, what would we need to add to make this possible?
