function main() {
  const items = ["spam", "egg", "sausage", "spam"];

  for (const item of items) {
    console.log(item);
  }
}

// How do range-based for loops actually work?
// What makes it so that an object can be traversed this way?

main();
