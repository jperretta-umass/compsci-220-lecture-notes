// Disable type checking so that we can practice
// thinking about scope and lifetime
// @ts-nocheck

// Draw and update the scope diagram at each line of the program.

// 1. --- Global scope ---

let spam = 42;  // global scope

// 2. --- Function parameter ---

function egg(param: number) {

// 3. --- Local variable ---

    let waluigi = "waaaa";

// 4. --- if-else local scope and parent scope ---

    if (param === 42) {
        let time = 6;
        console.log(spam);
    }
    else {
        console.log(waluigi);
    }

// 5. --- Inside function, call function defined below in the global scope ---

    console.log(zap());
}

function zap() {
    console.log("zap!");
}

export {};
