class Countdown {
    constructor(public count: number) {}
    
    tick(): number {
        if (this.count == 0) {
            return this.count;
        }
        
        const to_return = this.count;
        this.count -= 1;
        return to_return;
    }
}

const c = new Countdown(3);
console.log(c.tick(), c.tick(), c.tick(), c.tick());
