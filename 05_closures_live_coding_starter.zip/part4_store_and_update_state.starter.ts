class Countdown {
    constructor(public count: number) {}

    tick(): number {
        if (this.count == 0) {
            return this.count;
        }

        const to_return = this.count;
        this.count -= 1;
        return to_return;
    }
}

const c = new Countdown(3);
console.log(c.tick(), c.tick(), c.tick(), c.tick());

// Write a function that returns a closure (i.e., a function)
// that behaves like Countdown instances when called.

// Implement the function here.
function make_countdown() {

}

// What happens if we call make_countdown more than once?

export {};
