// Scenario: We're writing a user input form library. 
// Programmers using the library need to be able to 
// configure validation checks on their fields.

type ValidatorFunc = (value: number) => void;

function define_field(field_name: string, validators: ValidatorFunc[]) {
  return new Field(field_name, validators)
}

class Field {
  constructor(private name: string, private validators: ValidatorFunc[]) {}
  check(value: number) {
    for (const validator of this.validators) {
      validator(value);
    }
  }
}

// const age_field = 
// const reservation_party_size = 
