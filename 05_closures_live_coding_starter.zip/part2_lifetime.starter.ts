// Disable type checking so that we can practice
// thinking about scope and lifetime
// @ts-nocheck

// 1. What is the output of this code? ---------------------------------
function example1() {
  let spam = random_int();
  if (spam === 42) {
      let egg = 43;
  }
  console.log(egg);
}
example1();

// 2. What is the output of this code? ---------------------------------
// Comment out the call to example1() above and uncomment the call
// to example2() below before running.

function example2() {
  let func = () => {
    console.log("WAA");
  };
  let spam = random_int();
  if (spam === 42) {
    let egg = "LUIGI";

    function inner_func() {
      console.log(egg);
    }
    func = inner_func;
  }
  func();
}
// example2();

// ---------------------------------------------------------------------

function random_int() {
  return Math.random() < 0.5 ? 42 : 43;
}

export {};
