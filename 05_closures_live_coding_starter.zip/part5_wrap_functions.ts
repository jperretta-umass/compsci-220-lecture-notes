// Scenario: We want to catch the errors thrown by 
// these functions and print the messages.

function defrangulate() {
    if (random_int() !== 42) {
        throw new Error("NOOOOOO");
    }
    return "such meaning!";
}

function zap() {
    if (random_int() !== 43) {
        throw new Error("WAAAAAAAAA");
    }
    return "WALUIIIIGI TIME!";
}

function random_int() {
  return Math.random() < 0.5 ? 42 : 43;
}
