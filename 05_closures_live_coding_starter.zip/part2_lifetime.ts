// Disable type checking so that we can practice 
// thinking about scope and lifetime
// @ts-nocheck

// What is the output of this code?
let spam = random_int();  // definition of random_int omitted for brevity
if (spam === 42) {
    let egg = 43;
}
console.log(egg);

// What about this? (comment out above code first)

let func = () => { 
    console.log("WAA"); 
}; 
let spam = random_int();
if (spam === 42) {
    let egg = "LUIGI";
    
    function inner_func() {
        console.log(egg);
    }
    func = inner_func;
}
func();
