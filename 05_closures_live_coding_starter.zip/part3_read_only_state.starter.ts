// Scenario: We're writing a user input form library.
// Programmers using the library need to be able to
// configure validation checks on their fields.

type ValidatorFunc = (value: number) => void;

function define_field(field_name: string, validators: ValidatorFunc[]) {
  return new Field(field_name, validators)
}

class Field {
  constructor(private name: string, private validators: ValidatorFunc[]) {}
  check(value: number) {
    for (const validator of this.validators) {
      validator(value);
    }
  }
}

// Create an age Field with a validator function that checks that
// the value is >= 0
// const age_field =

// Create a reservation party size Field with a
// validator function that checks that the value is >= 1
// const reservation_party_size =

// From a code quality perspective, what's wrong/less-than-ideal
// about what we wrote?

export {};
