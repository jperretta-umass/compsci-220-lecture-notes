class Thing {
  constructor() {
    this.spam = 42;
    this.egg = 43;
  }
}

let thing = new Thing();
// What would you expect this to print in another programming language?
console.log(thing.waluigi);

// What about this?
// console.log(thing.waluigi.time);

// What about this?
// console.log(thing.waluigi + 1);
