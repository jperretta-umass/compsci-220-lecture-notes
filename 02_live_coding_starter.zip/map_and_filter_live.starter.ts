import { map } from "./map_and_filter.js";

function main() {
  array_map_and_filter();
}

function array_map_and_filter() {
  const distances = [2.8, 0.500001, 6.74256, 1.3333333];

  // Convert this code to use Array.map
  console.log(map(distances, (distance) => distance.toFixed(2)));
  console.log(distances.filter((distance) => distance < 3));
}

function exercise_map_and_filter() {
    const filenames = ["spam.txt", "egg.txt", "", "sausage", ""];

    // Write an expression that evaluates to a new array in which:
    // - Filenames ending in .txt have their extension changed to .md
    // - Filenames not originally ending in .txt are discarded.
    // You may find String.endsWith to be helpful:
    //   https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/endsWith
}

main();

export {};
