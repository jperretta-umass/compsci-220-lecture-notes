function main() {
  whyTypeScript();
}

function whyTypeScript() {
    // class Thing {
    //   spam: number;
    //   egg: number;
    //   constructor() {
    //       this.spam = 42;
    //       this.egg = 43;
    //   }
    // }

    // let thing = new Thing();
    // console.log(thing.waluigi + 1);


    // Strict null checks

    // let spam: string = null;

    // let spam: string | null = null;

    // if (spam.length > 0) {
    //     console.log(string);
    // }



    // let spam: string | null = null;

    // if (spam === null) {
    //     console.log("Value is null");
    // }
    // else if (spam.length > 0) {
    //     console.log(string);
    // }

    // if (spam !== null && spam.length > 0) {
    //     console.log(string);
    // }

    // What does this code output?
    // let values: number[] = [1, 2, 3];
    // let spam: number = values[5];
    // console.log(spam);
}

main();

export {};
