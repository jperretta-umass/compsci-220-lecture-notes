// In the expression below, state the type at each placeholder in the comments.

import { map } from "./map_and_filter.js";

// If a type can't be determined, state as such.
function exercise0_map_type_deduction() {
  const nums = [42, 43, 44];
  const result = map(
    nums,  // ???A - What is the type of nums?
    // ???B - What is the type of the input parameter `n`?
    // ???C - What is the return type of the arrow function?
    (n) => n.toString(),
  );  // What is the return type of this call to map?
  console.log(result);
}

// In the expression below, state the type at each placeholder in the comments.
// If a type can't be determined, state as such.
//
// Complete this exercise on paper without the assistance of any tools
// (that includes hovering your mouse over the code to reveal
// the type of an expression).
//
// A solution to this exercise can be found in the notes.
function exercise1_type_deduction() {
  const distances = [2.8, 0.500001, 6.74256, 1.3333333];

  distances // ???A - What is the type of `distances`?
    // ???B - What is the type of the input parameter `distance`?
    // ???C - What is the return type of the arrow function?
    // ???D - What is the return type of `.map`?
    .map((distance) => distance.toFixed(2))
    // ???E - What is the type of the input parameter `distance`?
    // ???F - What is the return type of the arrow function?
    // ???G - What is the return type of filter?
    // .filter((distance) => distance < 3);
}

export {};
