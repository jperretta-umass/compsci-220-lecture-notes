type MapFuncType<InputType, OutputType> = (value: InputType) => OutputType;

export function map<InputType, OutputType>(
  input: InputType[],
  func: MapFuncType<InputType, OutputType>,
): OutputType[] {
  const result = [];
  for (const item of input) {
    result.push(func(item));
  }
  return result;
}

type ConditionFuncType<ElementType> = (value: ElementType) => boolean;

export function filter<ElementType>(
  array: ElementType[],
  conditionFunc: ConditionFuncType<ElementType>,
): ElementType[] {
  const result: ElementType[] = [];
  for (const item of array) {
    if (conditionFunc(item)) {
      result.push(item);
    }
  }
  return result;
}
